package com.ctg.ag.sdk.biz.aep_rule_engine;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class SaasCreateRuleRequest extends BaseApiRequest {

    public SaasCreateRuleRequest(){
        super(RequestFormat.type("POST", "application/json; charset=UTF-8"), "20200111000503"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new SaasCreateRuleResponse();
    }
    
}