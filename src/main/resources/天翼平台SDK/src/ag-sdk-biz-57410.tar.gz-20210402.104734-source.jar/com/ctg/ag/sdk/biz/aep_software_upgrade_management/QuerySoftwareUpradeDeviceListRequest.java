package com.ctg.ag.sdk.biz.aep_software_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QuerySoftwareUpradeDeviceListRequest extends BaseApiRequest {

    public QuerySoftwareUpradeDeviceListRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20200529233027"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("isSelectDevice", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("deviceIdSearch", ParamPosition.QUERY)
        , new Meta("deviceNameSearch", ParamPosition.QUERY)
        , new Meta("imeiSearch", ParamPosition.QUERY)
        , new Meta("deviceGroupIdSearch", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QuerySoftwareUpradeDeviceListResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamIsSelectDevice(){
    	return this.getParam("isSelectDevice");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamIsSelectDevice(Object value){
    	this.setParam("isSelectDevice", value);
    	return this;
    }
    
    public List<String> getParamsIsSelectDevice(){
    	return this.getParams("isSelectDevice");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamIsSelectDevice(Object value){
    	this.addParam("isSelectDevice", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsIsSelectDevice(Iterable<?> values){
    	this.addParams("isSelectDevice", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamDeviceIdSearch(){
    	return this.getParam("deviceIdSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamDeviceIdSearch(Object value){
    	this.setParam("deviceIdSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceIdSearch(){
    	return this.getParams("deviceIdSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamDeviceIdSearch(Object value){
    	this.addParam("deviceIdSearch", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsDeviceIdSearch(Iterable<?> values){
    	this.addParams("deviceIdSearch", values);
    	return this;
    }
    
    public String getParamDeviceNameSearch(){
    	return this.getParam("deviceNameSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamDeviceNameSearch(Object value){
    	this.setParam("deviceNameSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceNameSearch(){
    	return this.getParams("deviceNameSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamDeviceNameSearch(Object value){
    	this.addParam("deviceNameSearch", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsDeviceNameSearch(Iterable<?> values){
    	this.addParams("deviceNameSearch", values);
    	return this;
    }
    
    public String getParamImeiSearch(){
    	return this.getParam("imeiSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamImeiSearch(Object value){
    	this.setParam("imeiSearch", value);
    	return this;
    }
    
    public List<String> getParamsImeiSearch(){
    	return this.getParams("imeiSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamImeiSearch(Object value){
    	this.addParam("imeiSearch", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsImeiSearch(Iterable<?> values){
    	this.addParams("imeiSearch", values);
    	return this;
    }
    
    public String getParamDeviceGroupIdSearch(){
    	return this.getParam("deviceGroupIdSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest setParamDeviceGroupIdSearch(Object value){
    	this.setParam("deviceGroupIdSearch", value);
    	return this;
    }
    
    public List<String> getParamsDeviceGroupIdSearch(){
    	return this.getParams("deviceGroupIdSearch");
    }

    public QuerySoftwareUpradeDeviceListRequest addParamDeviceGroupIdSearch(Object value){
    	this.addParam("deviceGroupIdSearch", value);
    	return this;
    }
    
    public QuerySoftwareUpradeDeviceListRequest addParamsDeviceGroupIdSearch(Iterable<?> values){
    	this.addParams("deviceGroupIdSearch", values);
    	return this;
    }
    
}