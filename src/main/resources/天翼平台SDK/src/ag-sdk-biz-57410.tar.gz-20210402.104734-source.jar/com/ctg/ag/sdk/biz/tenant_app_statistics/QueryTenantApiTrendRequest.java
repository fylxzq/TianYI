package com.ctg.ag.sdk.biz.tenant_app_statistics;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryTenantApiTrendRequest extends BaseApiRequest {

    public QueryTenantApiTrendRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201225122606"
        , new Meta("dateType", ParamPosition.QUERY)
        , new Meta("dataType", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryTenantApiTrendResponse();
    }
    
    public String getParamDateType(){
    	return this.getParam("dateType");
    }

    public QueryTenantApiTrendRequest setParamDateType(Object value){
    	this.setParam("dateType", value);
    	return this;
    }
    
    public List<String> getParamsDateType(){
    	return this.getParams("dateType");
    }

    public QueryTenantApiTrendRequest addParamDateType(Object value){
    	this.addParam("dateType", value);
    	return this;
    }
    
    public QueryTenantApiTrendRequest addParamsDateType(Iterable<?> values){
    	this.addParams("dateType", values);
    	return this;
    }
    
    public String getParamDataType(){
    	return this.getParam("dataType");
    }

    public QueryTenantApiTrendRequest setParamDataType(Object value){
    	this.setParam("dataType", value);
    	return this;
    }
    
    public List<String> getParamsDataType(){
    	return this.getParams("dataType");
    }

    public QueryTenantApiTrendRequest addParamDataType(Object value){
    	this.addParam("dataType", value);
    	return this;
    }
    
    public QueryTenantApiTrendRequest addParamsDataType(Iterable<?> values){
    	this.addParams("dataType", values);
    	return this;
    }
    
}