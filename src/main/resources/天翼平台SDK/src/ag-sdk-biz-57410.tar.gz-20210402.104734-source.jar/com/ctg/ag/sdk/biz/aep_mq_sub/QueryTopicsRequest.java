package com.ctg.ag.sdk.biz.aep_mq_sub;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryTopicsRequest extends BaseApiRequest {

    public QueryTopicsRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201218153456"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryTopicsResponse();
    }
    
}