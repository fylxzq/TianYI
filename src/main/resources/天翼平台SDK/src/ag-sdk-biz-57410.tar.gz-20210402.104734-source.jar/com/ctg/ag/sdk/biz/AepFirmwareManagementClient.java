package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_firmware_management.UpdateFirmwareRequest;
import com.ctg.ag.sdk.biz.aep_firmware_management.UpdateFirmwareResponse;
import com.ctg.ag.sdk.biz.aep_firmware_management.QueryFirmwareListRequest;
import com.ctg.ag.sdk.biz.aep_firmware_management.QueryFirmwareListResponse;
import com.ctg.ag.sdk.biz.aep_firmware_management.QueryFirmwareRequest;
import com.ctg.ag.sdk.biz.aep_firmware_management.QueryFirmwareResponse;
import com.ctg.ag.sdk.biz.aep_firmware_management.DeleteFirmwareRequest;
import com.ctg.ag.sdk.biz.aep_firmware_management.DeleteFirmwareResponse;

public final class AepFirmwareManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepFirmwareManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepFirmwareManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_firmware_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_firmware_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_firmware_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_firmware_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepFirmwareManagementClient build(BuilderParams params) {
				return new AepFirmwareManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepFirmwareManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public UpdateFirmwareResponse UpdateFirmware(UpdateFirmwareRequest request) throws Exception {
		String apiPath = "/firmware";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateFirmwareResponse> UpdateFirmware(UpdateFirmwareRequest request, ApiCallBack<UpdateFirmwareRequest, UpdateFirmwareResponse> callback) {
		String apiPath = "/firmware";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryFirmwareListResponse QueryFirmwareList(QueryFirmwareListRequest request) throws Exception {
		String apiPath = "/firmwares";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryFirmwareListResponse> QueryFirmwareList(QueryFirmwareListRequest request, ApiCallBack<QueryFirmwareListRequest, QueryFirmwareListResponse> callback) {
		String apiPath = "/firmwares";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryFirmwareResponse QueryFirmware(QueryFirmwareRequest request) throws Exception {
		String apiPath = "/firmware";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryFirmwareResponse> QueryFirmware(QueryFirmwareRequest request, ApiCallBack<QueryFirmwareRequest, QueryFirmwareResponse> callback) {
		String apiPath = "/firmware";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteFirmwareResponse DeleteFirmware(DeleteFirmwareRequest request) throws Exception {
		String apiPath = "/firmware";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteFirmwareResponse> DeleteFirmware(DeleteFirmwareRequest request, ApiCallBack<DeleteFirmwareRequest, DeleteFirmwareResponse> callback) {
		String apiPath = "/firmware";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}