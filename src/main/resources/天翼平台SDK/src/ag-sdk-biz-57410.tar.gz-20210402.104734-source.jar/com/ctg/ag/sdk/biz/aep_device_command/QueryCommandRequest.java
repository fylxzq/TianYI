package com.ctg.ag.sdk.biz.aep_device_command;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryCommandRequest extends BaseApiRequest {

    public QueryCommandRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190712225241"
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("commandId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("deviceId", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryCommandResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryCommandRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryCommandRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryCommandRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamCommandId(){
    	return this.getParam("commandId");
    }

    public QueryCommandRequest setParamCommandId(Object value){
    	this.setParam("commandId", value);
    	return this;
    }
    
    public List<String> getParamsCommandId(){
    	return this.getParams("commandId");
    }

    public QueryCommandRequest addParamCommandId(Object value){
    	this.addParam("commandId", value);
    	return this;
    }
    
    public QueryCommandRequest addParamsCommandId(Iterable<?> values){
    	this.addParams("commandId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryCommandRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryCommandRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryCommandRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public QueryCommandRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public QueryCommandRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public QueryCommandRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
}