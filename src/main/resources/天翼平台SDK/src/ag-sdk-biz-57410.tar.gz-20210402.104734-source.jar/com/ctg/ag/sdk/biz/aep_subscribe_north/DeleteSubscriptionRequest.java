package com.ctg.ag.sdk.biz.aep_subscribe_north;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteSubscriptionRequest extends BaseApiRequest {

    public DeleteSubscriptionRequest(){
        super(RequestFormat.type("DELETE", "application/x-www-form-urlencoded; charset=UTF-8"), "20181031202023"
        , new Meta("subId", ParamPosition.QUERY)
        , new Meta("deviceId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("subLevel", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new DeleteSubscriptionResponse();
    }
    
    public String getParamSubId(){
    	return this.getParam("subId");
    }

    public DeleteSubscriptionRequest setParamSubId(Object value){
    	this.setParam("subId", value);
    	return this;
    }
    
    public List<String> getParamsSubId(){
    	return this.getParams("subId");
    }

    public DeleteSubscriptionRequest addParamSubId(Object value){
    	this.addParam("subId", value);
    	return this;
    }
    
    public DeleteSubscriptionRequest addParamsSubId(Iterable<?> values){
    	this.addParams("subId", values);
    	return this;
    }
    
    public String getParamDeviceId(){
    	return this.getParam("deviceId");
    }

    public DeleteSubscriptionRequest setParamDeviceId(Object value){
    	this.setParam("deviceId", value);
    	return this;
    }
    
    public List<String> getParamsDeviceId(){
    	return this.getParams("deviceId");
    }

    public DeleteSubscriptionRequest addParamDeviceId(Object value){
    	this.addParam("deviceId", value);
    	return this;
    }
    
    public DeleteSubscriptionRequest addParamsDeviceId(Iterable<?> values){
    	this.addParams("deviceId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public DeleteSubscriptionRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public DeleteSubscriptionRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public DeleteSubscriptionRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamSubLevel(){
    	return this.getParam("subLevel");
    }

    public DeleteSubscriptionRequest setParamSubLevel(Object value){
    	this.setParam("subLevel", value);
    	return this;
    }
    
    public List<String> getParamsSubLevel(){
    	return this.getParams("subLevel");
    }

    public DeleteSubscriptionRequest addParamSubLevel(Object value){
    	this.addParam("subLevel", value);
    	return this;
    }
    
    public DeleteSubscriptionRequest addParamsSubLevel(Iterable<?> values){
    	this.addParams("subLevel", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public DeleteSubscriptionRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public DeleteSubscriptionRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public DeleteSubscriptionRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}