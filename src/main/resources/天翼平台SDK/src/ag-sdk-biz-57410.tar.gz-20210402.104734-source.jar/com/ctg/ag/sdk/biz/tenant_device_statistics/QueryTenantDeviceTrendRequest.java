package com.ctg.ag.sdk.biz.tenant_device_statistics;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryTenantDeviceTrendRequest extends BaseApiRequest {

    public QueryTenantDeviceTrendRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201225122550"
        , new Meta("dateType", ParamPosition.QUERY)
        , new Meta("type", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryTenantDeviceTrendResponse();
    }
    
    public String getParamDateType(){
    	return this.getParam("dateType");
    }

    public QueryTenantDeviceTrendRequest setParamDateType(Object value){
    	this.setParam("dateType", value);
    	return this;
    }
    
    public List<String> getParamsDateType(){
    	return this.getParams("dateType");
    }

    public QueryTenantDeviceTrendRequest addParamDateType(Object value){
    	this.addParam("dateType", value);
    	return this;
    }
    
    public QueryTenantDeviceTrendRequest addParamsDateType(Iterable<?> values){
    	this.addParams("dateType", values);
    	return this;
    }
    
    public String getParamType(){
    	return this.getParam("type");
    }

    public QueryTenantDeviceTrendRequest setParamType(Object value){
    	this.setParam("type", value);
    	return this;
    }
    
    public List<String> getParamsType(){
    	return this.getParams("type");
    }

    public QueryTenantDeviceTrendRequest addParamType(Object value){
    	this.addParam("type", value);
    	return this;
    }
    
    public QueryTenantDeviceTrendRequest addParamsType(Iterable<?> values){
    	this.addParams("type", values);
    	return this;
    }
    
}