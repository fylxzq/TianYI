package com.ctg.ag.sdk.biz.aep_nb_device_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class BatchCreateNBDeviceRequest extends BaseApiRequest {

    public BatchCreateNBDeviceRequest(){
        super(RequestFormat.type("POST", "application/json; charset=UTF-8"), "20200828140355"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new BatchCreateNBDeviceResponse();
    }
    
}