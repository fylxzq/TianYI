package com.ctg.ag.sdk.biz.aep_public_product_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class InstantiateProductRequest extends BaseApiRequest {

    public InstantiateProductRequest(){
        super(RequestFormat.type("POST", "application/json; charset=UTF-8"), "20200801233037"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new InstantiateProductResponse();
    }
    
}