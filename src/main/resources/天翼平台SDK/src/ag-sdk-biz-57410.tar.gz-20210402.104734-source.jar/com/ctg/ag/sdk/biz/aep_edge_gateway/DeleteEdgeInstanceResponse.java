package com.ctg.ag.sdk.biz.aep_edge_gateway;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteEdgeInstanceResponse extends BaseApiResponse {
}