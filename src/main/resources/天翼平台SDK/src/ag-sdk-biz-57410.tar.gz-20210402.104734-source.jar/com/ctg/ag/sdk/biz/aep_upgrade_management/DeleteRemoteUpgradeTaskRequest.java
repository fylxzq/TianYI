package com.ctg.ag.sdk.biz.aep_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class DeleteRemoteUpgradeTaskRequest extends BaseApiRequest {

    public DeleteRemoteUpgradeTaskRequest(){
        super(RequestFormat.type("DELETE", "application/x-www-form-urlencoded; charset=UTF-8"), "20190615001444"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("updateBy", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new DeleteRemoteUpgradeTaskResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public DeleteRemoteUpgradeTaskRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public DeleteRemoteUpgradeTaskRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public DeleteRemoteUpgradeTaskRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public DeleteRemoteUpgradeTaskRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public DeleteRemoteUpgradeTaskRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public DeleteRemoteUpgradeTaskRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamUpdateBy(){
    	return this.getParam("updateBy");
    }

    public DeleteRemoteUpgradeTaskRequest setParamUpdateBy(Object value){
    	this.setParam("updateBy", value);
    	return this;
    }
    
    public List<String> getParamsUpdateBy(){
    	return this.getParams("updateBy");
    }

    public DeleteRemoteUpgradeTaskRequest addParamUpdateBy(Object value){
    	this.addParam("updateBy", value);
    	return this;
    }
    
    public DeleteRemoteUpgradeTaskRequest addParamsUpdateBy(Iterable<?> values){
    	this.addParams("updateBy", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public DeleteRemoteUpgradeTaskRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public DeleteRemoteUpgradeTaskRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public DeleteRemoteUpgradeTaskRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}