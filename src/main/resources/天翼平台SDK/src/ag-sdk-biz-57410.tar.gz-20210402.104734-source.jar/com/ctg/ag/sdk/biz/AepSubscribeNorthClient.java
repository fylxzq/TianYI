package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_subscribe_north.GetSubscriptionRequest;
import com.ctg.ag.sdk.biz.aep_subscribe_north.GetSubscriptionResponse;
import com.ctg.ag.sdk.biz.aep_subscribe_north.GetSubscriptionsListRequest;
import com.ctg.ag.sdk.biz.aep_subscribe_north.GetSubscriptionsListResponse;
import com.ctg.ag.sdk.biz.aep_subscribe_north.DeleteSubscriptionRequest;
import com.ctg.ag.sdk.biz.aep_subscribe_north.DeleteSubscriptionResponse;
import com.ctg.ag.sdk.biz.aep_subscribe_north.CreateSubscriptionRequest;
import com.ctg.ag.sdk.biz.aep_subscribe_north.CreateSubscriptionResponse;

public final class AepSubscribeNorthClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepSubscribeNorthClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepSubscribeNorthClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_subscribe_north");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_subscribe_north");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_subscribe_north");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_subscribe_north");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepSubscribeNorthClient build(BuilderParams params) {
				return new AepSubscribeNorthClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepSubscribeNorthClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public GetSubscriptionResponse GetSubscription(GetSubscriptionRequest request) throws Exception {
		String apiPath = "/subscription";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetSubscriptionResponse> GetSubscription(GetSubscriptionRequest request, ApiCallBack<GetSubscriptionRequest, GetSubscriptionResponse> callback) {
		String apiPath = "/subscription";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetSubscriptionsListResponse GetSubscriptionsList(GetSubscriptionsListRequest request) throws Exception {
		String apiPath = "/subscribes";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetSubscriptionsListResponse> GetSubscriptionsList(GetSubscriptionsListRequest request, ApiCallBack<GetSubscriptionsListRequest, GetSubscriptionsListResponse> callback) {
		String apiPath = "/subscribes";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteSubscriptionResponse DeleteSubscription(DeleteSubscriptionRequest request) throws Exception {
		String apiPath = "/subscription";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteSubscriptionResponse> DeleteSubscription(DeleteSubscriptionRequest request, ApiCallBack<DeleteSubscriptionRequest, DeleteSubscriptionResponse> callback) {
		String apiPath = "/subscription";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateSubscriptionResponse CreateSubscription(CreateSubscriptionRequest request) throws Exception {
		String apiPath = "/subscription";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateSubscriptionResponse> CreateSubscription(CreateSubscriptionRequest request, ApiCallBack<CreateSubscriptionRequest, CreateSubscriptionResponse> callback) {
		String apiPath = "/subscription";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}