package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_device_event.QueryEventListRequest;
import com.ctg.ag.sdk.biz.aep_device_event.QueryEventListResponse;
import com.ctg.ag.sdk.biz.aep_device_event.QueryDeviceEventListRequest;
import com.ctg.ag.sdk.biz.aep_device_event.QueryDeviceEventListResponse;
import com.ctg.ag.sdk.biz.aep_device_event.QueryDeviceEventTotalRequest;
import com.ctg.ag.sdk.biz.aep_device_event.QueryDeviceEventTotalResponse;

public final class AepDeviceEventClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceEventClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceEventClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_device_event");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_device_event");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_device_event");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_device_event");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepDeviceEventClient build(BuilderParams params) {
				return new AepDeviceEventClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepDeviceEventClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryEventListResponse QueryEventList(QueryEventListRequest request) throws Exception {
		String apiPath = "/events";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryEventListResponse> QueryEventList(QueryEventListRequest request, ApiCallBack<QueryEventListRequest, QueryEventListResponse> callback) {
		String apiPath = "/events";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryDeviceEventListResponse QueryDeviceEventList(QueryDeviceEventListRequest request) throws Exception {
		String apiPath = "/device/events";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceEventListResponse> QueryDeviceEventList(QueryDeviceEventListRequest request, ApiCallBack<QueryDeviceEventListRequest, QueryDeviceEventListResponse> callback) {
		String apiPath = "/device/events";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryDeviceEventTotalResponse QueryDeviceEventTotal(QueryDeviceEventTotalRequest request) throws Exception {
		String apiPath = "/device/events/total";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceEventTotalResponse> QueryDeviceEventTotal(QueryDeviceEventTotalRequest request, ApiCallBack<QueryDeviceEventTotalRequest, QueryDeviceEventTotalResponse> callback) {
		String apiPath = "/device/events/total";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}