package com.ctg.ag.sdk.biz.usr;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class SdkDownloadResponse extends BaseApiResponse {
}