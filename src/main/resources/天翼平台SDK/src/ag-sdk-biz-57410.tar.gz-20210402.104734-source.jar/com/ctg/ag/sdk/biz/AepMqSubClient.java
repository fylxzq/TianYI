package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_mq_sub.QueryServiceStateRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryServiceStateResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.OpenMqServiceRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.OpenMqServiceResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.CreateTopicRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.CreateTopicResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryTopicInfoRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryTopicInfoResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryTopicCacheInfoRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryTopicCacheInfoResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryTopicsRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.QueryTopicsResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.ChangeTopicInfoRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.ChangeTopicInfoResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.QuerySubRulesRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.QuerySubRulesResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.ChangeSubRulesRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.ChangeSubRulesResponse;
import com.ctg.ag.sdk.biz.aep_mq_sub.ClosePushServiceRequest;
import com.ctg.ag.sdk.biz.aep_mq_sub.ClosePushServiceResponse;

public final class AepMqSubClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepMqSubClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepMqSubClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_mq_sub");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_mq_sub");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_mq_sub");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_mq_sub");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepMqSubClient build(BuilderParams params) {
				return new AepMqSubClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepMqSubClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryServiceStateResponse QueryServiceState(QueryServiceStateRequest request) throws Exception {
		String apiPath = "/mqStat";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryServiceStateResponse> QueryServiceState(QueryServiceStateRequest request, ApiCallBack<QueryServiceStateRequest, QueryServiceStateResponse> callback) {
		String apiPath = "/mqStat";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public OpenMqServiceResponse OpenMqService(OpenMqServiceRequest request) throws Exception {
		String apiPath = "/mqStat";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<OpenMqServiceResponse> OpenMqService(OpenMqServiceRequest request, ApiCallBack<OpenMqServiceRequest, OpenMqServiceResponse> callback) {
		String apiPath = "/mqStat";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateTopicResponse CreateTopic(CreateTopicRequest request) throws Exception {
		String apiPath = "/topic";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateTopicResponse> CreateTopic(CreateTopicRequest request, ApiCallBack<CreateTopicRequest, CreateTopicResponse> callback) {
		String apiPath = "/topic";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryTopicInfoResponse QueryTopicInfo(QueryTopicInfoRequest request) throws Exception {
		String apiPath = "/topic";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryTopicInfoResponse> QueryTopicInfo(QueryTopicInfoRequest request, ApiCallBack<QueryTopicInfoRequest, QueryTopicInfoResponse> callback) {
		String apiPath = "/topic";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryTopicCacheInfoResponse QueryTopicCacheInfo(QueryTopicCacheInfoRequest request) throws Exception {
		String apiPath = "/topic/cache";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryTopicCacheInfoResponse> QueryTopicCacheInfo(QueryTopicCacheInfoRequest request, ApiCallBack<QueryTopicCacheInfoRequest, QueryTopicCacheInfoResponse> callback) {
		String apiPath = "/topic/cache";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryTopicsResponse QueryTopics(QueryTopicsRequest request) throws Exception {
		String apiPath = "/topics";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryTopicsResponse> QueryTopics(QueryTopicsRequest request, ApiCallBack<QueryTopicsRequest, QueryTopicsResponse> callback) {
		String apiPath = "/topics";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public ChangeTopicInfoResponse ChangeTopicInfo(ChangeTopicInfoRequest request) throws Exception {
		String apiPath = "/topic";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ChangeTopicInfoResponse> ChangeTopicInfo(ChangeTopicInfoRequest request, ApiCallBack<ChangeTopicInfoRequest, ChangeTopicInfoResponse> callback) {
		String apiPath = "/topic";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QuerySubRulesResponse QuerySubRules(QuerySubRulesRequest request) throws Exception {
		String apiPath = "/rule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QuerySubRulesResponse> QuerySubRules(QuerySubRulesRequest request, ApiCallBack<QuerySubRulesRequest, QuerySubRulesResponse> callback) {
		String apiPath = "/rule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public ChangeSubRulesResponse ChangeSubRules(ChangeSubRulesRequest request) throws Exception {
		String apiPath = "/rule";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ChangeSubRulesResponse> ChangeSubRules(ChangeSubRulesRequest request, ApiCallBack<ChangeSubRulesRequest, ChangeSubRulesResponse> callback) {
		String apiPath = "/rule";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public ClosePushServiceResponse ClosePushService(ClosePushServiceRequest request) throws Exception {
		String apiPath = "/mqStat";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<ClosePushServiceResponse> ClosePushService(ClosePushServiceRequest request, ApiCallBack<ClosePushServiceRequest, ClosePushServiceResponse> callback) {
		String apiPath = "/mqStat";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}