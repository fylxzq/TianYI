package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_edge_gateway.DeleteEdgeInstanceDeviceRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.DeleteEdgeInstanceDeviceResponse;
import com.ctg.ag.sdk.biz.aep_edge_gateway.QueryEdgeInstanceDeviceRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.QueryEdgeInstanceDeviceResponse;
import com.ctg.ag.sdk.biz.aep_edge_gateway.CreateEdgeInstanceRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.CreateEdgeInstanceResponse;
import com.ctg.ag.sdk.biz.aep_edge_gateway.EdgeInstanceDeployRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.EdgeInstanceDeployResponse;
import com.ctg.ag.sdk.biz.aep_edge_gateway.DeleteEdgeInstanceRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.DeleteEdgeInstanceResponse;
import com.ctg.ag.sdk.biz.aep_edge_gateway.AddEdgeInstanceDeviceRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.AddEdgeInstanceDeviceResponse;
import com.ctg.ag.sdk.biz.aep_edge_gateway.AddEdgeInstanceDriveRequest;
import com.ctg.ag.sdk.biz.aep_edge_gateway.AddEdgeInstanceDriveResponse;

public final class AepEdgeGatewayClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepEdgeGatewayClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepEdgeGatewayClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_edge_gateway");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_edge_gateway");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_edge_gateway");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_edge_gateway");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepEdgeGatewayClient build(BuilderParams params) {
				return new AepEdgeGatewayClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepEdgeGatewayClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public DeleteEdgeInstanceDeviceResponse DeleteEdgeInstanceDevice(DeleteEdgeInstanceDeviceRequest request) throws Exception {
		String apiPath = "/instance/devices";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteEdgeInstanceDeviceResponse> DeleteEdgeInstanceDevice(DeleteEdgeInstanceDeviceRequest request, ApiCallBack<DeleteEdgeInstanceDeviceRequest, DeleteEdgeInstanceDeviceResponse> callback) {
		String apiPath = "/instance/devices";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryEdgeInstanceDeviceResponse QueryEdgeInstanceDevice(QueryEdgeInstanceDeviceRequest request) throws Exception {
		String apiPath = "/instance/devices";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryEdgeInstanceDeviceResponse> QueryEdgeInstanceDevice(QueryEdgeInstanceDeviceRequest request, ApiCallBack<QueryEdgeInstanceDeviceRequest, QueryEdgeInstanceDeviceResponse> callback) {
		String apiPath = "/instance/devices";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateEdgeInstanceResponse CreateEdgeInstance(CreateEdgeInstanceRequest request) throws Exception {
		String apiPath = "/instance";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateEdgeInstanceResponse> CreateEdgeInstance(CreateEdgeInstanceRequest request, ApiCallBack<CreateEdgeInstanceRequest, CreateEdgeInstanceResponse> callback) {
		String apiPath = "/instance";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public EdgeInstanceDeployResponse EdgeInstanceDeploy(EdgeInstanceDeployRequest request) throws Exception {
		String apiPath = "/instance/settings";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<EdgeInstanceDeployResponse> EdgeInstanceDeploy(EdgeInstanceDeployRequest request, ApiCallBack<EdgeInstanceDeployRequest, EdgeInstanceDeployResponse> callback) {
		String apiPath = "/instance/settings";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteEdgeInstanceResponse DeleteEdgeInstance(DeleteEdgeInstanceRequest request) throws Exception {
		String apiPath = "/instance";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteEdgeInstanceResponse> DeleteEdgeInstance(DeleteEdgeInstanceRequest request, ApiCallBack<DeleteEdgeInstanceRequest, DeleteEdgeInstanceResponse> callback) {
		String apiPath = "/instance";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public AddEdgeInstanceDeviceResponse AddEdgeInstanceDevice(AddEdgeInstanceDeviceRequest request) throws Exception {
		String apiPath = "/instance/device";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<AddEdgeInstanceDeviceResponse> AddEdgeInstanceDevice(AddEdgeInstanceDeviceRequest request, ApiCallBack<AddEdgeInstanceDeviceRequest, AddEdgeInstanceDeviceResponse> callback) {
		String apiPath = "/instance/device";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public AddEdgeInstanceDriveResponse AddEdgeInstanceDrive(AddEdgeInstanceDriveRequest request) throws Exception {
		String apiPath = "/instance/drive";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<AddEdgeInstanceDriveResponse> AddEdgeInstanceDrive(AddEdgeInstanceDriveRequest request, ApiCallBack<AddEdgeInstanceDriveRequest, AddEdgeInstanceDriveResponse> callback) {
		String apiPath = "/instance/drive";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}