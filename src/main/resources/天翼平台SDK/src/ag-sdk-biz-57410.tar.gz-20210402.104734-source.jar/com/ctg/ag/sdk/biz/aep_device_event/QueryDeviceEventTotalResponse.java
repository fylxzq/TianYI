package com.ctg.ag.sdk.biz.aep_device_event;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryDeviceEventTotalResponse extends BaseApiResponse {
}