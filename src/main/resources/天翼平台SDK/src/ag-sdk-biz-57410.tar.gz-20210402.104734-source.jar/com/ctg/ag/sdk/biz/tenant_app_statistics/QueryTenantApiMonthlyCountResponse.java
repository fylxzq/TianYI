package com.ctg.ag.sdk.biz.tenant_app_statistics;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryTenantApiMonthlyCountResponse extends BaseApiResponse {
}